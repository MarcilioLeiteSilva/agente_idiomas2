import sqlite3
from datetime import datetime


class Store:
    def __init__(self, path="agent.db"):
        self.path = path
        self._init()

    def _init(self):
        with sqlite3.connect(self.path) as con:
            con.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
              session_id TEXT PRIMARY KEY,
              output_mode TEXT NOT NULL DEFAULT 'text',
              language TEXT NOT NULL DEFAULT 'pt',
              updated_at TEXT NOT NULL
            )""")

            con.execute("""
            CREATE TABLE IF NOT EXISTS messages (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              session_id TEXT NOT NULL,
              role TEXT NOT NULL,
              content TEXT NOT NULL,
              created_at TEXT NOT NULL
            )""")

            # ✅ NOVO: resumo persistido da conversa
            con.execute("""
            CREATE TABLE IF NOT EXISTS summaries (
              session_id TEXT PRIMARY KEY,
              summary TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )""")

            # ✅ NOVO: sistema de créditos
            con.execute("""
            CREATE TABLE IF NOT EXISTS credits (
              session_id TEXT PRIMARY KEY,
              balance_cents INTEGER NOT NULL DEFAULT 100,
              updated_at TEXT NOT NULL
            )""")


            # ✅ NOVO: log de uso
            con.execute("""
            CREATE TABLE IF NOT EXISTS usage_logs (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              session_id TEXT NOT NULL,
              provider TEXT NOT NULL,
              model TEXT NOT NULL,
              type TEXT NOT NULL, -- 'text', 'stt', 'tts'
              input_units INTEGER NOT NULL DEFAULT 0, -- tokens or chars
              output_units INTEGER NOT NULL DEFAULT 0, -- tokens or chars
              cost_millicents INTEGER NOT NULL DEFAULT 0,
              created_at TEXT NOT NULL
            )""")

            # ✅ NOVO: perfil do aluno (Fase 1 - Passo 1)
            # 🔄 UPDATE (Fase 1 - Passo 2): Adicionado native_language
            con.execute("""
            CREATE TABLE IF NOT EXISTS user_profile (
              user_id TEXT PRIMARY KEY,
              native_language TEXT DEFAULT 'pt', -- Novo campo
              target_language TEXT NOT NULL,
              level TEXT DEFAULT 'A1',
              goals TEXT,
              correction_style TEXT DEFAULT 'moderado',
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )""")
            
            # Migração automática Fase 1 Passo 2: Adicionar native_language se não existir
            try:
                # Verifica se a coluna existe
                columns = [info[1] for info in con.execute("PRAGMA table_info(user_profile)")]
                if "native_language" not in columns:
                    con.execute("ALTER TABLE user_profile ADD COLUMN native_language TEXT DEFAULT 'pt'")
            except Exception as e:
                print(f"Erro na migração de user_profile: {e}")

            # ✅ NOVO: Progresso do aluno (Fase 1 - Passo 3)
            con.execute("""
            CREATE TABLE IF NOT EXISTS user_progress (
              user_id TEXT,
              lesson_id TEXT,
              target_language TEXT,
              level TEXT,
              status TEXT, -- started, completed
              score INTEGER DEFAULT 0,
              started_at TEXT,
              completed_at TEXT,
              attempts INTEGER DEFAULT 1,
              PRIMARY KEY (user_id, lesson_id)
            )""")

            # ✅ NOVO: Estado da lição ativa (Fase 1 - Passo 3)
            con.execute("""
            CREATE TABLE IF NOT EXISTS user_lesson_state (
              user_id TEXT PRIMARY KEY,
              lesson_id TEXT,
              step_index INTEGER DEFAULT 0,
              active INTEGER DEFAULT 0,
              updated_at TEXT
            )""")

            # ✅ NOVO: Detalhes das tentativas (Fase 1 - Passo 4)
            con.execute("""
            CREATE TABLE IF NOT EXISTS lesson_attempt_details (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id TEXT,
              lesson_id TEXT,
              step_index INTEGER,
              user_input TEXT,
              overall_score INTEGER,
              feedback_json TEXT,
              timestamp TEXT
            )""")
            
    def _exists(self, session_id: str) -> bool:
        with sqlite3.connect(self.path) as con:
            row = con.execute("SELECT 1 FROM sessions WHERE session_id=?", (session_id,)).fetchone()
        return bool(row)
    
    # ... (existing get_session, upsert_session, add_message, get_recent_messages, count_messages, get_summary, upsert_summary, get_credits, upsert_credits, deduct_credits, add_usage_log, get_profile, create_or_update_profile) ...

    def get_session(self, session_id: str):
        with sqlite3.connect(self.path) as con:
            row = con.execute(
                "SELECT session_id, output_mode, language FROM sessions WHERE session_id=?",
                (session_id,)
            ).fetchone()

        if not row:
            return self.upsert_session(session_id, output_mode="text", language="pt")

        return {"session_id": row[0], "output_mode": row[1], "language": row[2]}

    def upsert_session(self, session_id: str, output_mode: str | None = None, language: str | None = None):
        now = datetime.now().isoformat()
        current = self.get_session(session_id) if self._exists(session_id) else {"output_mode": "text", "language": "pt"}

        out = output_mode or current["output_mode"]
        lang = language or current["language"]

        with sqlite3.connect(self.path) as con:
            con.execute("""
            INSERT INTO sessions(session_id, output_mode, language, updated_at)
            VALUES(?,?,?,?)
            ON CONFLICT(session_id) DO UPDATE SET
              output_mode=excluded.output_mode,
              language=excluded.language,
              updated_at=excluded.updated_at
            """, (session_id, out, lang, now))

        return {"session_id": session_id, "output_mode": out, "language": lang}

    def add_message(self, session_id: str, role: str, content: str):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute(
                "INSERT INTO messages(session_id, role, content, created_at) VALUES(?,?,?,?)",
                (session_id, role, content, now)
            )

    # ✅ NOVO: puxar últimas mensagens (janela curta)
    def get_recent_messages(self, session_id: str, limit: int = 12):
        with sqlite3.connect(self.path) as con:
            rows = con.execute("""
              SELECT role, content FROM messages
              WHERE session_id=?
              ORDER BY id DESC
              LIMIT ?
            """, (session_id, limit)).fetchall()
        rows.reverse()
        return [{"role": r, "content": c} for (r, c) in rows]

    # ✅ NOVO: contagem de mensagens (para decidir quando resumir)
    def count_messages(self, session_id: str) -> int:
        with sqlite3.connect(self.path) as con:
            row = con.execute("""
              SELECT COUNT(*) FROM messages WHERE session_id=?
            """, (session_id,)).fetchone()
        return int(row[0] if row else 0)

    # ✅ NOVO: resumo
    def get_summary(self, session_id: str) -> str:
        with sqlite3.connect(self.path) as con:
            row = con.execute("SELECT summary FROM summaries WHERE session_id=?", (session_id,)).fetchone()
        return row[0] if row else ""

    def upsert_summary(self, session_id: str, summary: str):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("""
            INSERT INTO summaries(session_id, summary, updated_at)
            VALUES(?,?,?)
            ON CONFLICT(session_id) DO UPDATE SET
              summary=excluded.summary,
              updated_at=excluded.updated_at
            """, (session_id, summary, now))

    # ✅ NOVO: créditos e uso
    def get_credits(self, session_id: str) -> int:
        with sqlite3.connect(self.path) as con:
            row = con.execute("SELECT balance_cents FROM credits WHERE session_id=?", (session_id,)).fetchone()
        if not row:
            self.upsert_credits(session_id, 100) # 100 centavos default
            return 100
        return row[0]

    def upsert_credits(self, session_id: str, balance: int):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("""
            INSERT INTO credits(session_id, balance_cents, updated_at)
            VALUES(?,?,?)
            ON CONFLICT(session_id) DO UPDATE SET
              balance_cents=excluded.balance_cents,
              updated_at=excluded.updated_at
            """, (session_id, balance, now))

    def deduct_credits(self, session_id: str, amount_cents: int):
        with sqlite3.connect(self.path) as con:
            con.execute("""
            UPDATE credits SET balance_cents = MAX(0, balance_cents - ?), updated_at = ?
            WHERE session_id = ?
            """, (amount_cents, datetime.now().isoformat(), session_id))

    def add_usage_log(self, session_id: str, provider: str, model: str, utype: str, input_units: int, output_units: int, cost_milli: int):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("""
            INSERT INTO usage_logs(session_id, provider, model, type, input_units, output_units, cost_millicents, created_at)
            VALUES(?,?,?,?,?,?,?,?)
            """, (session_id, provider, model, utype, input_units, output_units, cost_milli, now))

    # ✅ NOVO: Perfil do Aluno
    def get_profile(self, user_id: str):
        with sqlite3.connect(self.path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM user_profile WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None

    def create_or_update_profile(self, user_id: str, target_language: str, native_language: str = 'pt', level: str = 'A1', goals: str = '', correction_style: str = 'moderado'):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            # Check if exists to preserve created_at if updating
            existing = con.execute("SELECT created_at FROM user_profile WHERE user_id=?", (user_id,)).fetchone()
            created_at = existing[0] if existing else now
            
            # Garantir default se native_language vier None
            if not native_language: native_language = 'pt'

            con.execute("""
            INSERT INTO user_profile(user_id, native_language, target_language, level, goals, correction_style, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(user_id) DO UPDATE SET
              native_language=excluded.native_language,
              target_language=excluded.target_language,
              level=excluded.level,
              goals=excluded.goals,
              correction_style=excluded.correction_style,
              updated_at=excluded.updated_at
            """, (user_id, native_language, target_language, level, goals, correction_style, created_at, now))
        
        return self.get_profile(user_id)

    def add_lesson_attempt(self, user_id: str, lesson_id: str, step_index: int, user_input: str, overall_score: int, feedback_json: str):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("""
            INSERT INTO lesson_attempt_details(user_id, lesson_id, step_index, user_input, overall_score, feedback_json, timestamp)
            VALUES(?,?,?,?,?,?,?)
            """, (user_id, lesson_id, step_index, user_input, overall_score, feedback_json, now))

    def get_lesson_average_score(self, user_id: str, lesson_id: str) -> int:
        with sqlite3.connect(self.path) as con:
            # 1. Pegar quando a lição começou
            start_row = con.execute("SELECT started_at FROM user_progress WHERE user_id=? AND lesson_id=?", (user_id, lesson_id)).fetchone()
            if not start_row: return 0
            
            started_at = start_row[0]
            
            # 2. Pegar média de tentativas após started_at
            avg_row = con.execute("""
            SELECT AVG(overall_score) FROM lesson_attempt_details 
            WHERE user_id=? AND lesson_id=? AND timestamp >= ?
            """, (user_id, lesson_id, started_at)).fetchone()
            
            if avg_row and avg_row[0] is not None:
                return int(avg_row[0])
            return 0

    # ✅ NOVO: Lições e Progresso (Fase 1 - Passo 3)
    def start_lesson(self, user_id: str, lesson_id: str, target_language: str, level: str):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            # 1. Update user_progress (init or increment attempts)
            existing = con.execute("SELECT attempts FROM user_progress WHERE user_id=? AND lesson_id=?", (user_id, lesson_id)).fetchone()
            attempts = existing[0] + 1 if existing else 1
            
            con.execute("""
            INSERT INTO user_progress(user_id, lesson_id, target_language, level, status, score, started_at, attempts)
            VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(user_id, lesson_id) DO UPDATE SET
              status='started',
              started_at=excluded.started_at,
              attempts=excluded.attempts
            """, (user_id, lesson_id, target_language, level, "started", 0, now, attempts))
            
            # 2. Update active lesson state
            con.execute("""
            INSERT INTO user_lesson_state(user_id, lesson_id, step_index, active, updated_at)
            VALUES(?,?,?,?,?)
            ON CONFLICT(user_id) DO UPDATE SET
              lesson_id=excluded.lesson_id,
              step_index=excluded.step_index,
              active=excluded.active,
              updated_at=excluded.updated_at
            """, (user_id, lesson_id, 0, 1, now))

    def get_lesson_state(self, user_id: str):
        with sqlite3.connect(self.path) as con:
            con.row_factory = sqlite3.Row
            row = con.execute("SELECT * FROM user_lesson_state WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None

    def set_lesson_state(self, user_id: str, step_index: int, active: int = 1):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("""
            UPDATE user_lesson_state SET step_index=?, active=?, updated_at=? WHERE user_id=?
            """, (step_index, active, now, user_id))

    def stop_lesson(self, user_id: str):
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
            con.execute("UPDATE user_lesson_state SET active=0, updated_at=? WHERE user_id=?", (now, user_id))

    def complete_lesson(self, user_id: str, lesson_id: str, score: int = -1):
        # Se score -1, calcular média
        if score == -1:
            score = self.get_lesson_average_score(user_id, lesson_id)
            
        now = datetime.now().isoformat()
        with sqlite3.connect(self.path) as con:
             # Mark progress as completed
             con.execute("""
             UPDATE user_progress SET status='completed', score=?, completed_at=? 
             WHERE user_id=? AND lesson_id=?
             """, (score, now, user_id, lesson_id))
             
             # Deactivate lesson state
             con.execute("UPDATE user_lesson_state SET active=0, updated_at=? WHERE user_id=?", (now, user_id))

    def get_progress(self, user_id: str):
        with sqlite3.connect(self.path) as con:
            con.row_factory = sqlite3.Row
            rows = con.execute("SELECT * FROM user_progress WHERE user_id=?", (user_id,)).fetchall()
        return [dict(r) for r in rows]
