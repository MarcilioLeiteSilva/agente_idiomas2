class ExerciseEngine:
    def __init__(self):
        pass

    def generate_exercise(self, topic: str, level: str):
        """Generate a new exercise."""
        pass
