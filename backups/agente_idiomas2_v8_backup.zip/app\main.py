import os
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Form, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional, Literal, Any, Dict
from pathlib import Path
import json

from core.store import Store
from core.core_openai import handle_message, handle_message_stream
from core.logger import setup_logger

logger = setup_logger("agente_idiomas")

app = FastAPI(title="Agente Idiomas (Local)")

# CORS (dev local)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles

WEB_DIR = Path(__file__).resolve().parent.parent / "web"

@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")



if not os.getenv("OPENAI_API_KEY"):
    raise RuntimeError("Defina OPENAI_API_KEY no arquivo .env")

store = Store("agent.db")

class AudioIn(BaseModel):
    mime: str = "audio/ogg"
    base64: str

class MessageIn(BaseModel):
    type: Literal["text", "audio"]
    text: Optional[str] = None
    audio: Optional[AudioIn] = None

class UIActionIn(BaseModel):
    action_id: str
    value: Optional[str] = None

class MessageReq(BaseModel):
    session_id: str
    message: MessageIn
    ui_action: Optional[UIActionIn] = None
    meta: Optional[Dict[str, Any]] = None

class SettingsReq(BaseModel):
    session_id: str
    output_mode: Optional[Literal["text", "audio"]] = None
    language: Optional[Literal["pt", "en", "fr", "auto"]] = None

@app.get("/v1/health")
def health():
    return {"ok": True}

@app.post("/v1/message")
def v1_message(req: MessageReq):
    return handle_message(
        store=store,
        session_id=req.session_id,
        message=req.message.model_dump(),
        ui_action=req.ui_action.model_dump() if req.ui_action else None,
    )

# ✅ NOVO: streaming SSE
@app.post("/v1/stream")
def v1_stream(req: MessageReq):
    def gen():
        try:
            for chunk in handle_message_stream(
                store=store,
                session_id=req.session_id,
                message=req.message.model_dump(),
                ui_action=req.ui_action.model_dump() if req.ui_action else None,
            ):
                yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)}, ensure_ascii=False)}\n\n"
            
    return StreamingResponse(gen(), media_type="text/event-stream; charset=utf-8")

@app.post("/v1/settings")
def v1_settings(req: SettingsReq):
    state = store.upsert_session(req.session_id, output_mode=req.output_mode, language=req.language)
    return {"ok": True, "state": state}

@app.get("/v1/credits")
def v1_credits(session_id: str):
    return {"credits": store.get_credits(session_id)}

# ✅ NOVO: Endpoint de Tradução
class TranslateReq(BaseModel):
    source_lang: str
    target_lang: str
    text: str

@app.post("/v1/translate")
def v1_translate(req: TranslateReq):
    from core.core_openai import handle_translate
    return handle_translate(req.source_lang, req.target_lang, req.text)

# ✅ NOVO: Endpoint de Intérprete
from typing import Annotated

@app.post("/v1/interpret")
async def v1_interpret(
    source_lang: Annotated[str, Form()],
    target_lang: Annotated[str, Form()],
    file: Annotated[UploadFile, File()]
):
    # Save temp file
    temp_filename = f"temp_{file.filename}"
    with open(temp_filename, "wb") as buffer:
        buffer.write(await file.read())
        
    try:
        from core.core_openai import handle_interpret
        response = handle_interpret(temp_filename, source_lang, target_lang)
        return response
    finally:
        if os.path.exists(temp_filename):
            os.remove(temp_filename)

@app.post("/v1/interpret-auto")
async def v1_interpret_auto(
    source_lang_a: Annotated[str, Form()],
    source_lang_b: Annotated[str, Form()],
    file: Annotated[UploadFile, File()]
):
    # Save temp file
    temp_filename = f"temp_auto_{file.filename}"
    with open(temp_filename, "wb") as buffer:
        buffer.write(await file.read())
        
    try:
        from core.core_openai import handle_interpret_auto
        response = handle_interpret_auto(temp_filename, source_lang_a, source_lang_b)
        return response
    finally:
        if os.path.exists(temp_filename):
            os.remove(temp_filename)

# ✅ NOVO: Endpoints de Perfil (Fase 1)
# ✅ NOVO: Endpoints de Perfil (Fase 1)
class ProfileReq(BaseModel):
    user_id: str
    native_language: str = "pt" # Novo campo (Fase 1 - Passo 2)
    target_language: str
    level: str = "A1"
    goals: Optional[str] = ""
    correction_style: str = "moderado"

@app.post("/v1/profile")
def v1_create_profile(req: ProfileReq):
    return store.create_or_update_profile(
        user_id=req.user_id,
        native_language=req.native_language,
        target_language=req.target_language,
        level=req.level,
        goals=req.goals,
        correction_style=req.correction_style
    )

@app.get("/v1/profile")
def v1_get_profile(user_id: str):
    profile = store.get_profile(user_id)
    if not profile:
        return {"error": "Profile not found"}
    return profile

# ✅ NOVO: Endpoint de Lições (Fase 1 - Passo 2)
# ✅ NOVO: Endpoint de Lições (Fase 1 - Passo 2)
from learning.lesson_engine import LessonEngine
from learning.scoring_engine import ScoringEngine # Fase 1 - Passo 4

lesson_engine = LessonEngine()
scoring_engine = ScoringEngine()

@app.get("/v1/lessons")
def v1_lessons(target_language: Optional[str] = None, level: Optional[str] = None, user_id: Optional[str] = None):
    # Se user_id fornecido, carregar defaults do perfil
    if user_id:
        profile = store.get_profile(user_id)
        if profile:
            if not target_language: target_language = profile.get("target_language")
            if not level: level = profile.get("level")
            
    # Fallbacks globais
    if not target_language: target_language = "en"
    if not level: level = "A1"
    
    return lesson_engine.load_lessons(target_language, level)

# ✅ NOVO: Fluxo de Lição e Progresso (Fase 1 - Passo 3)

class LessonStartReq(BaseModel):
    user_id: str
    lesson_id: str

@app.post("/v1/lesson/start")
def v1_lesson_start(req: LessonStartReq):
    # 1. Identificar detalhes da lição pelo ID (assumindo prefixo ou busca global)
    parts = req.lesson_id.split("_")
    if len(parts) >= 2:
        target_lang = parts[0]
        lesson = lesson_engine.get_lesson_by_id(target_lang, req.lesson_id)
    else:
        target_lang = "en"
        lesson = lesson_engine.get_lesson_by_id("en", req.lesson_id)

    if not lesson:
        return {"error": "Lesson not found"}
        
    level = "A1" 
    if "_a1_" in req.lesson_id: level = "A1"
    elif "_a2_" in req.lesson_id: level = "A2"
    elif "_b1_" in req.lesson_id: level = "B1"
    
    store.start_lesson(req.user_id, req.lesson_id, target_lang, level)
    
    return {
        "status": "started",
        "lesson": lesson, 
        "first_step": lesson.get("script_steps", [])[0] if lesson.get("script_steps") else "Start!"
    }

class LessonNextReq(BaseModel):
    user_id: str
    user_input: str

@app.post("/v1/lesson/next")
def v1_lesson_next(req: LessonNextReq):
    state = store.get_lesson_state(req.user_id)
    if not state or not state["active"]:
        return {"error": "No active lesson"}
    
    current_step_idx = state["step_index"]
    
    # Carregar dados da lição
    prog_rows = store.get_progress(req.user_id)
    prog = next((p for p in prog_rows if p["lesson_id"] == state["lesson_id"]), None)
    
    if not prog:
        return {"error": "Progress not found for active lesson"}
        
    target_lang = prog["target_language"]
    lesson = lesson_engine.get_lesson_by_id(target_lang, state["lesson_id"])
    
    if not lesson:
        return {"error": "Lesson content missing"}
        
    steps = lesson.get("script_steps", [])
    
    # --- Scoring (Fase 1 - Passo 4) ---
    # Avaliar a resposta ANTES de avançar
    current_instruction = steps[current_step_idx] if current_step_idx < len(steps) else "Review"
    
    # Contexto para o prompt
    eval_context = {
        "title": lesson.get("title"),
        "objective": lesson.get("objective"),
        "target_vocab": lesson.get("target_vocab", []),
        "target_grammar": lesson.get("target_grammar", []),
        "current_step_instruction": current_instruction
    }
    
    eval_result = scoring_engine.evaluate_response(req.user_input, eval_context, target_lang)
    
    # Persistir tentativa
    store.add_lesson_attempt(
        user_id=req.user_id,
        lesson_id=state["lesson_id"],
        step_index=current_step_idx,
        user_input=req.user_input,
        overall_score=eval_result.get("overall_score", 0),
        feedback_json=json.dumps(eval_result, ensure_ascii=False)
    )
    # ----------------------------------

    next_step = current_step_idx + 1
    
    if next_step >= len(steps):
        # Lição acabando, mas ainda retornamos o feedback do ultimo input
        return {
            "status": "finished", 
            "message": "Lesson steps completed. Call /complete to finish.",
            "feedback": eval_result # Retorna feedback da ultima interacao
        }
        
    store.set_lesson_state(req.user_id, next_step, active=1)
    
    # Store interaction for chat history
    store.add_message(req.user_id, "user", req.user_input)
    # Adicionar também o feedback do tutor no histórico
    if eval_result.get("feedback_text"):
        store.add_message(req.user_id, "assistant", f"[Feedback]: {eval_result['feedback_text']}")

    instruction = steps[next_step]
    store.add_message(req.user_id, "assistant", f"[Lesson Tutor]: {instruction}")

    return {
        "status": "ongoing",
        "step_index": next_step,
        "instruction": instruction,
        "feedback": eval_result # Feedback da resposta anterior
    }

class LessonCompleteReq(BaseModel):
    user_id: str
    score: int = -1 # Default -1 para indicar "calcular média"

@app.post("/v1/lesson/complete")
def v1_lesson_complete(req: LessonCompleteReq):
    state = store.get_lesson_state(req.user_id)
    if not state or not state["active"]:
        return {"error": "No active lesson to complete"}
        
    # Se vier -1, store calcula a média
    store.complete_lesson(req.user_id, state["lesson_id"], req.score)
    
    # Recuperar o score final salvo para retornar (opcional, requer nova query ou confiar na logica)
    # Vamos retornar o que foi pedido ou avisar que foi calculado
    return {"status": "completed", "final_score_type": "average" if req.score == -1 else "manual"}

class LessonStopReq(BaseModel):
    user_id: str

@app.post("/v1/lesson/stop")
def v1_lesson_stop(req: LessonStopReq):
    store.stop_lesson(req.user_id)
    return {"status": "stopped"}

@app.get("/v1/progress")
def v1_progress(user_id: str):
    return store.get_progress(user_id)

app.mount("/", StaticFiles(directory=WEB_DIR), name="static")
