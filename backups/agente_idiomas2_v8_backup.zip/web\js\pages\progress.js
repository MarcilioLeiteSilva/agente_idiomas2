// web/js/pages/progress.js
import { apiCall } from "../api.js";
import { state } from "../state.js";

let container = null;

export async function mount(parent) {
    container = document.createElement("div");
    container.innerHTML = `<h3>Carregando progresso...</h3>`;
    parent.appendChild(container);

    try {
        const data = await apiCall(`/v1/progress?user_id=${state.sessionId}`);
        render(data);
    } catch (e) {
        container.innerHTML = `<p style="color:red">Erro: ${e.message}</p>`;
    }
}

export function unmount() {
    if (container) container.remove();
}

function render(list) {
    const completed = list.filter(p => p.status === 'completed');
    const avg = completed.length ? Math.round(completed.reduce((a, b) => a + (b.score || 0), 0) / completed.length) : 0;

    container.innerHTML = `
        <h2>Meu Progresso</h2>
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-val">${completed.length}</div>
                <div class="stat-lbl">Lições Concluídas</div>
            </div>
            <div class="stat-card">
                <div class="stat-val">${avg}</div>
                <div class="stat-lbl">Nota Média</div>
            </div>
        </div>
        
        <h3>Histórico</h3>
        <ul class="progress-list">
            ${list.reverse().map(item => `
                <li>
                    <strong>${item.lesson_id}</strong> - 
                    ${item.status === 'completed' ? `<span class="badge-success">Nota: ${item.score}</span>` : '<span class="badge-warn">Em andamento</span>'}
                    <small>(${new Date(item.started_at).toLocaleDateString()})</small>
                </li>
            `).join('')}
        </ul>
        ${list.length === 0 ? '<p>Nenhuma atividade registrada.</p>' : ''}
    `;
}
