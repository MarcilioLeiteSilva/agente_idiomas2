import json
import os
from pathlib import Path

class LessonEngine:
    def __init__(self, lessons_dir="learning/lessons"):
        self.lessons_dir = Path(lessons_dir)

    def load_lessons(self, target_language: str, level: str) -> dict:
        """Load lessons from JSON catalog."""
        if not target_language or not level:
             return {"error": "Missing parameters"}
             
        file_path = self.lessons_dir / target_language.lower() / f"{level.lower()}.json"
        
        if not file_path.exists():
            return {"error": "Catalog not found", "path": str(file_path)}
            
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except Exception as e:
            return {"error": f"Error loading catalog: {str(e)}"}

    def get_lesson_by_id(self, target_language: str, lesson_id: str):
        """Find a specific lesson in the catalog."""
        # Naive search strategy for now: Check all levels? Or just assume A1?
        # Ideally we should know the level, but let's check accessible files for that lang.
        # For this MVP step, we only have A1. But code should be robust.
        
        lang_dir = self.lessons_dir / target_language.lower()
        if not lang_dir.exists():
            return None
            
        # Iterate over all json files in lang dir
        for level_file in lang_dir.glob("*.json"):
            try:
                with open(level_file, "r", encoding="utf-8") as f:
                    catalog = json.load(f)
                    for lesson in catalog.get("lessons", []):
                        if lesson.get("lesson_id") == lesson_id:
                            return lesson
            except:
                continue
                
        return None
